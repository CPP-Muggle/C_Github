#ifndef PRINT1,PRINT2
#define PRINT1(a)(printf("%c\n",a))//print a if PRINT1 is called;
#define PRINT2(a,b)(printf("%c  %c\n",a,b))//print a and b if PRINT2 is called
#endif